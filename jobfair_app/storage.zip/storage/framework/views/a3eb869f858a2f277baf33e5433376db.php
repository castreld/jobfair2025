<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Perusahaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white">
    <div class="flex">
        <div class="w-64 min-h-screen bg-gray-800 p-4">
            <h1 class="text-2xl font-bold mb-8">Admin Jobfair</h1>
            <nav class="flex flex-col space-y-2">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="px-4 py-2 rounded hover:bg-gray-700">Dashboard</a>
                <a href="<?php echo e(route('admin.companies.index')); ?>" class="px-4 py-2 rounded bg-gray-700">Kelola Perusahaan</a>
                <a href="<?php echo e(route('admin.applicants.index')); ?>" class="px-4 py-2 rounded hover:bg-gray-700">Lihat Pelamar</a>
            </nav>
        </div>

        <div class="flex-1 p-8">
            <div class="flex justify-between items-center mb-8">
                <h2 class="text-3xl font-bold">Kelola Perusahaan</h2>
                <a href="<?php echo e(route('admin.companies.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    + Tambah Perusahaan
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="bg-green-500 text-white p-4 rounded mb-4">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-gray-800 p-6 rounded-lg shadow-lg">
                <table class="w-full text-left">
                    <thead>
                        <tr class="border-b border-gray-700">
                            <th class="py-2">Nama Perusahaan</th>
                            <th class="py-2">Jumlah Posisi</th>
                            <th class="py-2 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-b border-gray-700">
                            <td class="py-4"><?php echo e($company->name); ?></td>
                            <td class="py-4"><?php echo e($company->positions->count()); ?></td>
                            <td class="py-4 text-right">
                                <a href="<?php echo e(route('admin.companies.positions.index', $company)); ?>" class="bg-sky-600 hover:bg-sky-700 text-white font-bold py-2 px-4 rounded text-sm">
                                    Kelola Posisi
                                </a>
                                <a href="<?php echo e(route('admin.companies.edit', $company)); ?>" class="text-yellow-400 hover:text-yellow-300 ml-4">Ubah</a>
                                <form action="<?php echo e(route('admin.companies.destroy', $company)); ?>" method="POST" class="inline" onsubmit="return confirm('Yakin ingin menghapus perusahaan ini dan semua posisinya?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-400 ml-4">Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="py-4 text-center">Belum ada data perusahaan.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH D:\Project\jobfair2025\jobfair_app\resources\views/admin/companies/index.blade.php ENDPATH**/ ?>