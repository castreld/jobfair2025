<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Pelamar: <?php echo e($applicant->full_name); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white">
    <div class="flex">
        <div class="w-64 min-h-screen bg-gray-800 p-4">
            <h1 class="text-2xl font-bold mb-8">Admin Jobfair</h1>
             <nav class="flex flex-col space-y-2">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="px-4 py-2 rounded hover:bg-gray-700">Dashboard</a>
                <a href="<?php echo e(route('admin.companies.index')); ?>" class="px-4 py-2 rounded hover:bg-gray-700">Kelola Perusahaan</a>
                <a href="<?php echo e(route('admin.applicants.index')); ?>" class="px-4 py-2 rounded bg-gray-700">Lihat Pelamar</a>
            </nav>
        </div>

        <div class="flex-1 p-8">
            <div class="flex justify-between items-center mb-8">
                <h2 class="text-3xl font-bold">Detail Pelamar</h2>
                <a href="<?php echo e(route('admin.applicants.index')); ?>" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded">
                    &larr; Kembali ke Daftar
                </a>
            </div>

            <div class="bg-gray-800 p-8 rounded-lg shadow-lg">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div class="md:col-span-1 text-center">
                        <img src="<?php echo e(Storage::url($applicant->photo_path)); ?>" alt="Foto Pelamar" class="w-40 h-40 rounded-full mx-auto object-cover mb-4 border-4 border-gray-700">
                        <h3 class="text-2xl font-bold"><?php echo e($applicant->full_name); ?></h3>
                        <p class="text-gray-400"><?php echo e($applicant->applicant_id); ?></p>
                        <div class="mt-6 space-y-2">
                             <a href="<?php echo e(Storage::url($applicant->cv_path)); ?>" class="block w-full text-center bg-sky-600 hover:bg-sky-500 text-white font-bold py-2 px-4 rounded" download>Unduh CV</a>
                             <a href="<?php echo e(Storage::url($applicant->zip_path)); ?>" class="block w-full text-center bg-sky-600 hover:bg-sky-500 text-white font-bold py-2 px-4 rounded" download>Unduh Berkas (.zip)</a>
                        </div>
                    </div>

                    <div class="md:col-span-2 space-y-6">
                        <div>
                            <h4 class="text-xl font-semibold border-b border-gray-700 pb-2 mb-3">Informasi Lamaran</h4>
                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div><strong class="text-gray-400 block">Perusahaan:</strong> <?php echo e($applicant->company->name ?? 'N/A'); ?></div>
                                <div><strong class="text-gray-400 block">Posisi:</strong> <?php echo e($applicant->position->name ?? 'N/A'); ?></div>
                            </div>
                        </div>

                        <div>
                            <h4 class="text-xl font-semibold border-b border-gray-700 pb-2 mb-3">Kontak & Personal</h4>
                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div><strong class="text-gray-400 block">Email:</strong> <?php echo e($applicant->email); ?></div>
                                <div><strong class="text-gray-400 block">Telepon:</strong> <?php echo e($applicant->phone_number); ?></div>
                                <div class="col-span-2"><strong class="text-gray-400 block">Alamat:</strong> <?php echo e($applicant->address); ?></div>
                            </div>
                        </div>

                        <div>
                            <h4 class="text-xl font-semibold border-b border-gray-700 pb-2 mb-3">Pendidikan</h4>
                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div><strong class="text-gray-400 block">Institusi:</strong> <?php echo e($applicant->school_name); ?></div>
                                <div><strong class="text-gray-400 block">Jurusan:</strong> <?php echo e($applicant->major); ?></div>
                                <div><strong class="text-gray-400 block">Pendidikan Terakhir:</strong> <?php echo e($applicant->last_education); ?></div>
                                <div><strong class="text-gray-400 block">Tahun Lulus:</strong> <?php echo e($applicant->graduation_year); ?></div>
                            </div>
                        </div>

                        <div>
                            <h4 class="text-xl font-semibold border-b border-gray-700 pb-2 mb-3">Keterampilan & Portfolio</h4>
                            <div class="text-sm space-y-3">
                                <div>
                                    <strong class="text-gray-400 block mb-1">Keterampilan:</strong>
                                    <div class="flex flex-wrap gap-2">
                                        <?php $__currentLoopData = explode(',', $applicant->skills); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="bg-gray-700 text-gray-300 text-xs font-semibold px-2.5 py-0.5 rounded"><?php echo e(trim($skill)); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <?php if($applicant->portfolio_link): ?>
                                    <div><strong class="text-gray-400 block">Portfolio:</strong> <a href="<?php echo e($applicant->portfolio_link); ?>" class="text-sky-400 hover:underline" target="_blank"><?php echo e($applicant->portfolio_link); ?></a></div>
                                <?php elseif($applicant->portfolio_file_path): ?>
                                     <div><strong class="text-gray-400 block">Portfolio:</strong> <a href="<?php echo e(Storage::url($applicant->portfolio_file_path)); ?>" class="text-sky-400 hover:underline" download>Unduh File Portfolio</a></div>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div>
                            <h4 class="text-xl font-semibold border-b border-gray-700 pb-2 mb-3">Ringkasan Diri</h4>
                            <p class="text-sm text-gray-300"><?php echo e($applicant->personal_summary); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH D:\Project\jobfair2025\jobfair_app\resources\views/admin/applicants/show.blade.php ENDPATH**/ ?>