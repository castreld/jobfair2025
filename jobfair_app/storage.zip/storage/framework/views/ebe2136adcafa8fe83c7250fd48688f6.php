

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm text-center">
    <div class="card-header">
        <h1 class="card-title">Pendaftaran Berhasil!</h1>
    </div>
    <div class="card-body">
        <p class="fs-5">Terima kasih, <strong><?php echo e($applicant->full_name); ?></strong>. Data Anda telah kami terima.</p>
        <p>Silakan <strong>screenshot</strong> atau simpan QR Code di bawah ini. Tunjukkan QR Code ini kepada perwakilan perusahaan di lokasi job fair.</p>
        
        <div class="my-4">
            <?php echo QrCode::size(300)->generate(route('applicant.show', $applicant->uuid)); ?>

        </div>

        <h5 class="font-monospace">ID Pendaftaran Anda: <strong><?php echo e($applicant->applicant_id); ?></strong></h5>

        <p class="text-muted mt-3">QR Code ini adalah tiket digital Anda.</p>
        <a href="<?php echo e(route('applicant.create')); ?>" class="btn btn-secondary mt-3">Kembali ke Halaman Utama</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\jobfair2025\jobfair_app\resources\views/qr.blade.php ENDPATH**/ ?>